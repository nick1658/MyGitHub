#ifndef __LOG__
#define __LOG__

extern S16 coin_log (char *fmt, ...);

#endif



