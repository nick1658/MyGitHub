#ifndef __AD_FILTER__
#define __AD_FILTER__

#include "def.h"


extern U16 filterMedianAverageSample (U16 *adValueBuf, int sampleNum);
extern U16 filterMedianSample (U16 *adValueBuf, int sampleNum);

#endif

