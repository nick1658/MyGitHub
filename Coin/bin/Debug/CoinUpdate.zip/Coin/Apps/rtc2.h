void rtc_ticktime_enable(unsigned char bdata);
void rtc_realtime_display(void);
void rtc_enable(unsigned char bdata);
void rtc_print(void);
void rtc_settime(void);
